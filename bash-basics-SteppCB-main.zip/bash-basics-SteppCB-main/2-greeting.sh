#!/bin/bash

# Prompt the user to enter their name

# Print a personalized greeting message ("Hello, NAME! Welcome to the world of bash scripting.")
