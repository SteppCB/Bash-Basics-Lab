#!/bin/bash

# This script should output the text "Hello, World!" to the console when run