#!/bin/bash

# Define the path to the file_info.sh script
file_info_script="./4-file-info.sh"

# Define an array of test files to create
test_files=(
    "./test-file-1.txt"
    "./nonexistent_file.txt"
    "./test-file-2.txt"
)

# Create the test files with the specified timestamps
file="./test-file-1.txt"
created="202306220315"
modified="202306220315"

echo "Hello, World!" > "$file"

touch -t "$created" "$file"
touch -mt "$modified" "$file"

file="./test-file-2.txt"
created="202306220326"
modified="202306220326"

echo "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum." > "$file"

touch -t "$created" "$file"
touch -mt "$modified" "$file"

# Define an array of expected outputs corresponding to the test files
expected_outputs=(
    "File: ./test-file-1.txt
Size: 4.0K
Permissions: -rw-r--r--
Created: 2023-06-22 03:15:00.*
Modified: 2023-06-22 03:15:00.*"
    "Error: File './nonexistent_file.txt' does not exist."
    "File: ./test-file-2.txt
Size: 4.0K
Permissions: -rw-r--r--
Created: 2023-06-22 03:26:00.*
Modified: 2023-06-22 03:26:00.*"
)

# Perform the tests
for ((i = 0; i < ${#test_files[@]}; i++)); do
    file="${test_files[$i]}"
    expected_output="${expected_outputs[$i]}"

    echo "Testing file: $file"
    echo "---------------------"

    # Run the file_info.sh script with the current test file
    output=$(bash "$file_info_script" <<< "$file")

    # Verify the output using grep pattern matching
    if echo "$output" | grep -q -E "$expected_output"; then
        echo "Test Passed: Output is correct!"
    else
        echo "Test Failed: Output is incorrect."
        echo "Expected Output: $expected_output"
        echo "Actual Output: $output"
    fi

    echo "====================="
    echo
done

# Remove the test files
rm -f "${test_files[@]}"
