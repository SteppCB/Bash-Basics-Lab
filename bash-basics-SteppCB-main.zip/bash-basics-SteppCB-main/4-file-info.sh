#!/bin/bash

# Prompt the user to enter a file name/path


# Check if the file exists

  # If the file exists, print the following information:
    echo "File Information:"
    echo "-----------------"
    echo "File: $file"
    echo "Size: "
    echo "Permissions: "
    echo "Created: "
    echo "Modified: "

  # if the file doesn't exist, print an error message
    echo "Error: File '$file' does not exist."

